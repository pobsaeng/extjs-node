Ext.define('dbview.Application', {
    name: 'dbview',
    extend: 'Ext.app.Application',
    controllers: [
        'dbview.controller.Main'

    ],
	launch:function(){
	
	}
});
