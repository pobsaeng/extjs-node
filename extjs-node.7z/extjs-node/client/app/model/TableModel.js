Ext.define('dbview.model.TableModel', {
    extend: 'Ext.data.Model',
    fields:[]
});